export interface Movie {
    id: number;
    title: string;
    startHour: string;
    numberOfSeats: number;
    seats: MyType[];
}

interface MyType {
    number: number;
    isAvailable: number;
}