export interface Reservation {
    id: number;
    movie: string;
    seats: number[]; 
} 