import movies from "../data/movies.json";
import cinema from "../data/cinema.json";
import reservationJSON from '../data/reservations.json';
import {Movie} from "../models";
import { Reservation } from "../models/reservation";

export class Service1 {

  private _movieList: Movie[];
  private _reservationList: Reservation[];

  constructor() {
    this._movieList = cinema;
    this._reservationList = reservationJSON;
  }

  /**
   * getMovies
   * TODO: define and specify a return type. Normally, typescript will infere it
   * but for the purposes of this exercise, let's specify it
   */
  public getMovies(): Movie[] {
    console.log(`Retrieving movies data: ${JSON.stringify(this._movieList)}`);
    return this._movieList;
  }

  public getReservations(): Reservation[] {
    console.log(`Retrieving reservations data: ${JSON.stringify(this._reservationList)}`);
    console.log(this._reservationList);
    return this._reservationList;
  }

  public getMovie(id: number) {
    for (let i = 0; i < cinema.length; i++) {
      if (cinema[i].id === id) {
        return cinema[i];
      }
    }
    return "nu exista";
  }

  public getAvailableSeats(id: number): number[]{
    for(let i=0; i<this._movieList.length; i++){
      if(this._movieList[i].id === id){
        let movie = this._movieList[i]
        let availableSeats = []
        for(let j=0; j<movie.seats.length; j++){
          if(movie.seats[j].isAvailable === 1){
            availableSeats.push(movie.seats[j].number)
          }
        }
        return availableSeats;
      }
    }
    return [];
  }

  public addMovie(movie: Movie): Movie[] {
    this._movieList.push(movie);
    return this._movieList;
  }

  public makeReservation(movieName:string, seats:number[]): Reservation[] {
    //let emptyReservation: Reservation = {id: -1, movie: "", seats: []}
    for(let i = 0; i < this._movieList.length; i++) {
      if(movieName === this._movieList[i].title) {
        let movie = this._movieList[i];
        let availableSeats = this.getAvailableSeats(movie.id);
        if(seats.every(elem => availableSeats.indexOf(elem)>-1)){
          let id1 = Math.floor(Math.random()*1000)
          let reservation: Reservation = {id: id1, movie: movieName, seats: seats};
          console.log(reservation);
          this._reservationList.push(reservation);
          reservation.seats.forEach(e=>movie.seats[e-1].isAvailable=0);  
        }
      }
    }
    console.log(this._reservationList);
    return this._reservationList;
  }

  public deleteReservation(id: number): Reservation[] {
    let index=-1;
    for(let i=0; i<this._reservationList.length; i++){
      if(this._reservationList[i].id===id){
        index=i;
      }
    }
    if(index>=0){
      let movieName = this._reservationList[index].movie;
      for(let i=0; i<this._movieList.length; i++){
        if(this._movieList[i].title === movieName){
          this._reservationList[index].seats.forEach(e=>this._movieList[i].seats[e-1].isAvailable=1);
          break;
        }
      }
      this._reservationList.splice(index, 1);
    }
    return this._reservationList;
  }

  public deleteMovieExample() {
    console.log(`deleting last movie... ${JSON.stringify(this._movieList)}`);
    // Remove the last movie from the in-memory collection
    this._movieList.pop();
    return this._movieList;
}
}
