import express, {Application, Request, Response, NextFunction} from 'express';
import { Service1 } from './services';
const bodyParser = require('body-parser');

const port = Number(process.env.PORT || 3000);

const logRequest = (req: Request, res: Response, next: NextFunction) => {
  console.log(`${req.method} - ${req.originalUrl} ${JSON.stringify(req.params)}`);
  console.log(`${res.statusCode}`);
  next();
}

const app: Application = express();
app.use(logRequest);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get( "/", (req, res) => {
    res.send( "Hello Typescript Assignment" );
});

app.get( "/movies", (req, res) => {
  let service1 = new Service1();
  let response = service1.getMovies();
  res.send(response);
});

app.get("/movies/:id", (req,res)=>{
  let service = new Service1();
  let response = service.getAvailableSeats(parseInt(req.params.id));
  res.send(response);
})

app.get("/reservations", (req, res)=>{
  let service = new Service1();
  let response = service.getReservations();
  res.send(response);
})

app.post("/addReservation", (req, res)=>{
  let service = new Service1();
  let response = service.makeReservation(req.body.movie,req.body.seats);
  res.send(response);
})

app.post("/addMovie", (req, res)=>{
  let service = new Service1();
  let response = service.addMovie(req.body);
  res.send(response);
})

app.delete("/deleteReservation/:id", (req, res)=>{
  let service = new Service1();
  let response = service.deleteReservation(parseInt(req.params.id));
  res.send(response);
})

app.delete( "/deleteMovie", (req, res) => {
  let service1 = new Service1();
  let response = service1.deleteMovieExample();
  res.send(response);
});

app.listen(port, () => {
    console.log(`server started on port ${port}`);
});