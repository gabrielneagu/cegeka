﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab02
{
    public class SpaceSlotStrategy : IResourceStrategy
    {
        public int Allocate()
        {
            int resourceId;
            resourceId = FindFreeSpaceSlot();
            MarkSpaceSlotBusy(resourceId);
            return resourceId;
        }
        public void Deallocate(int resourceId)
        {
            MarkSpaceSlotFree(resourceId);
        }
        private int FindFreeSpaceSlot()
        {
            return new Random().Next() * 100;
        }
        private void MarkSpaceSlotBusy(int resourceId)
        {
            Console.WriteLine("Space slot Marked as busy for resourceId = " + resourceId);
        }
        private void MarkSpaceSlotFree(int resourceId)
        {
            Console.WriteLine("Space slot Marked as free for resourceId = " + resourceId);
        }
    }
}
