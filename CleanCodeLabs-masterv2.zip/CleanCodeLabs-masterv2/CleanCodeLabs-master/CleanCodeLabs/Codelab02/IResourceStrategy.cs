﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab02
{
    public interface IResourceStrategy
    {
        public int Allocate();
        public void Deallocate(int resourceId);

    }
}
