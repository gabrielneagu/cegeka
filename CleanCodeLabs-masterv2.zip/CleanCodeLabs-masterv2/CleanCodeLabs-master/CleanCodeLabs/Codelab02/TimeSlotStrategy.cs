﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab02
{
    public class TimeSlotStrategy : IResourceStrategy
    {
        public int Allocate()
        {
            int resourceId;
            resourceId = FindFreeTimeSlot();
            MarkTimeSlotBusy(resourceId);
            return resourceId;
        }
        public void Deallocate(int resourceId)
        {
            MarkTimeSlotFree(resourceId);
        }
        private int FindFreeTimeSlot()
        {
            return new Random().Next() * 50;
        }
        private void MarkTimeSlotBusy(int resourceId)
        {
            Console.WriteLine("Time slot Marked as busy for resourceId = " + resourceId);
        }
        private void MarkTimeSlotFree(int resourceId)
        {
            Console.WriteLine("Time slot Marked as free for resourceId = " + resourceId);
        }
    }
}
