﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab04.Interfaces
{
    public interface IRecharger
    {
        public string RechargeBatteries();
    }
}
