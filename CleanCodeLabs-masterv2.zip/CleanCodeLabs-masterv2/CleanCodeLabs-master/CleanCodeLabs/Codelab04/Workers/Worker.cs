﻿using CleanCodeLabs.Codelab04.Interfaces;

namespace CleanCodeLabs.Codelab04.Workers
{
    public class Worker : IWorker, IEater, IRecharger
    {
        protected Worker(string name)
        {
            Name = name;
        }

        public string Name { get; }

        public virtual string Eat()
        {
            return "I'm eating";
        }

        public virtual string RechargeBatteries()
        {
            return "I'm recharging my batteries";
        }

        public virtual string Work()
        {
            return "I'm working";
        }
    }
}