﻿using CleanCodeLabs.Codelab04.Interfaces;
using System;

namespace CleanCodeLabs.Codelab04.Workers
{
    public class Robot : Worker
    {
        public Robot(string name) : base(name)
        {
        }

        public override string Eat()
        {
            return "I do not have to eat, I'm a robot";
        }

        public override string RechargeBatteries()
        {
            return "RECHARGING BATTERIES, BEEP";
        }

        public override string Work()
        {
            return "DOING SO MUCH WORK, BEEP";
        }
    }
}