﻿using System;

namespace CleanCodeLabs.Codelab04.Workers
{
    public class Horse : Worker
    {
        public Horse(string name) : base(name)
        {
        }
        public override string Eat()
        {
            return "I'm eating human food";
        }

        public override string Work()
        {
            return "I'm working like a human being";
        }

        public override string RechargeBatteries()
        {
            return "I'm a horse, I do not have to recharge";
        }
    }
}