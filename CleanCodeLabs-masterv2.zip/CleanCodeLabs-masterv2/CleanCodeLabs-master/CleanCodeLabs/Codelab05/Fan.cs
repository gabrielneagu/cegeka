﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab05
{
    public class Fan : IElectronic
    {
        public void TurnOff()
        {
            Console.WriteLine("Fan turned on");
        }

        public void TurnOn()
        {
            Console.WriteLine("Fan turned off");
        }
    }
}
