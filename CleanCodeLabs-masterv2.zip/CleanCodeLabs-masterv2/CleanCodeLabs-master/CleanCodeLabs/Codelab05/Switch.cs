﻿using System.Drawing;

namespace CleanCodeLabs.Codelab05
{
    /// <summary>
    ///     A Switch to Turn something (in this case: a Lamp) ON or OFF
    /// </summary>
    internal class Switch
    {
        private readonly IElectronic _electronic;

        public Switch(IElectronic electronic)
        {
            _electronic = electronic;
        }
        public bool IsSwitchOn { get; private set; }

        public void Toggle()
        {
            IsSwitchOn = !IsSwitchOn;
            if (IsSwitchOn)
            {
                _electronic.TurnOn();
            }
            else
            {
                _electronic.TurnOff();
            }
        }
    }
}