﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeLabs.Codelab05
{
    public interface IElectronic
    {
        public void TurnOn();
        public void TurnOff();
    }
}
