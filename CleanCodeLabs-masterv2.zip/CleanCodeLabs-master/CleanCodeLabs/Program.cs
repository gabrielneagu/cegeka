﻿using System;
using CleanCodeLabs.Codelab04;

namespace CleanCodeLabs
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            FactoryApp.Run();
        }
    }
}