﻿# Design Principle

1. Decide what piece of code violates the SOLID - **Single Responsibility Principle**.
2. Refactor the code so that it no longer violates the principle.