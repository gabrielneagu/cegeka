﻿# Design Principle

1. Detect what piece of code should be refactored.
2. Apply SOLID principle **Interface Segregation** into your solution.