﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class PremiumCalculator : IFeeCalculator
    {
        public double CalculateAmount(Rental rental, double pricePerDay)
        {
            double thisAmount = 0;
            thisAmount += rental.DaysRented * pricePerDay * 1.5;
            return thisAmount;
        }
    }
}
