﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class RentalCarsBucuresti
    {
        private readonly List<Rental> _rentals = new List<Rental>();
        private readonly double pricePerDay = 30;
        public RentalCarsBucuresti(string name)
        {
            Name = name;
        }

        public string Name { get; }

        public void AddRental(Rental rental)
        {
            if (CheckEnoughPoints(rental))
            {
                _rentals.Add(rental);
                rental.Customer.AddRental(rental);
            }
            else
            {
                Console.WriteLine("Clientul nu are suficiente puncte pentru a inchiria o masina Luxury");
            }
        }
        public string Statement()
        {
            double totalAmountRegular = 0;
            double totalAmountMini = 0;
            double totalAmountPremium = 0;
            double totalAmountLuxury = 0;

            var r = "Rental Record for " + Name + "\n";
            r += "------------------------------\n";
            r += "Category   Total Income\n\n";
            var factory = new FeeCalculatorFactory();
            foreach (var each in _rentals)
            {
                double thisAmount = 0;
                var calculator = factory.GetFeeCalculator(each);
                thisAmount += calculator.CalculateAmount(each, pricePerDay);

                thisAmount = UpdateAmount(each, thisAmount);

                switch (each.Car.PriceCode)
                {
                    case PriceCode.Luxury:
                        totalAmountLuxury += thisAmount;
                        break;
                    case PriceCode.Regular:
                        totalAmountRegular += thisAmount;
                        break;
                    case PriceCode.Mini:
                        totalAmountMini += thisAmount;
                        break;
                    case PriceCode.Premium:
                        totalAmountPremium += thisAmount;
                        break;
                }
            }
            r += "Regular " + "\t" + totalAmountRegular + " EUR\n";
            r += "Premium " + "\t" + totalAmountPremium + " EUR\n";
            r += "Mini " + "\t" + totalAmountMini + " EUR\n";
            r += "Luxury " + "\t" + totalAmountLuxury + " EUR\n";
            return r;
        }

        private static double UpdateAmount(Rental each, double thisAmount)
        {
            if (each.Customer.FrequentRenterPoints >= 5)
            {
                if (each.Car.PriceCode != PriceCode.Luxury)
                {
                    thisAmount = thisAmount * 0.95;
                }
            }

            return thisAmount;
        }
        private static bool CheckEnoughPoints(Rental rental)
        {
            if (rental.Car.PriceCode == PriceCode.Luxury)
            {
                if (rental.Customer.FrequentRenterPoints >= 3)
                {
                    return true;
                }
                return false;
            }
            return true;
        }
    }
}
