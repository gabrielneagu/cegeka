﻿using System;
using System.Collections.Generic;

namespace RentalCars
{
    public class RentalCars : IRentalCars
    {
        private readonly List<Rental> _rentals = new List<Rental>();
        private readonly double pricePerDay = 20;
        public RentalCars(string name) 
        {
            Name = name;
        }

        public string Name { get; }

        public void AddRental(Rental rental)
        {
            _rentals.Add(rental);
            rental.Customer.AddRental(rental);
        }

        public string Statement()
        {
            double totalAmount = 0;

            var r = "Rental Record for " + Name + "\n";
            r += "------------------------------\n";
            var factory = new FeeCalculatorFactory();
            foreach (var each in _rentals)
            {
                double thisAmount = 0;
                var calculator = factory.GetFeeCalculator(each);
                thisAmount += calculator.CalculateAmount(each, pricePerDay);

                thisAmount = UpdateAmount(each, thisAmount);

                r += each.Customer.Name + "\t" + each.Car.Model + "\t" + each.DaysRented + "d \t" + thisAmount + " EUR\n";
                totalAmount += thisAmount;
            }
            r += "------------------------------\n";
            r += "Total revenue " + totalAmount + " EUR\n";

            return r;
        }
        private static double UpdateAmount(Rental each, double thisAmount)
        {
            if (each.Customer.FrequentRenterPoints >= 5)
            {
                thisAmount = thisAmount * 0.95;
            }

            return thisAmount;
        }
    }
}