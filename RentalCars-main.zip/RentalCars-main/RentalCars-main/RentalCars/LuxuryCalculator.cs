﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class LuxuryCalculator : IFeeCalculator
    {
        private const double additionalPrice = 40;
        public double CalculateAmount(Rental rental, double pricePerDay)
        {
            double thisAmount = 0;
            thisAmount += rental.DaysRented * (pricePerDay + additionalPrice); 
            return thisAmount;
        }
    }
}
