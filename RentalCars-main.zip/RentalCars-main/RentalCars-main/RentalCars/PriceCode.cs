﻿namespace RentalCars
{
    public enum PriceCode
    {
        Regular,
        Premium,
        Mini,
        Luxury
    }
}