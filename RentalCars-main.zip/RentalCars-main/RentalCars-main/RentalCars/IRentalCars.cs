﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public interface IRentalCars
    {
        public void AddRental(Rental rental);
        public string Statement();
    }
}
