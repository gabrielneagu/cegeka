﻿using System.Collections.Generic;

namespace RentalCars
{
    public class Customer
    {
        public Customer(string name)
        {
            Name = name;
        }

        public string Name { get; }

        public int FrequentRenterPoints { get; set; }

        public List<Rental> Rentals { get; } = new List<Rental>();

        public void AddRental(Rental rental)
        {
            Rentals.Add(rental);
            rental.Customer.FrequentRenterPoints += 1;
            if(rental.Car.PriceCode==PriceCode.Premium && rental.DaysRented > 1)
            {
                rental.Customer.FrequentRenterPoints += 1;
            }
        }
    }
}