﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class FeeCalculatorFactory
    {
        public IFeeCalculator GetFeeCalculator(Rental rental)
        {
            switch (rental.Car.PriceCode)
            {
                case PriceCode.Regular:
                    return new RegularCalculator();
                case PriceCode.Premium:
                    return new PremiumCalculator();
                case PriceCode.Mini:
                    return new MiniCalculator();
                case PriceCode.Luxury:
                    return new LuxuryCalculator();
                default:
                    throw new NotImplementedException();
            }
        }
    }
}
