﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public interface IFeeCalculator
    {
        public double CalculateAmount(Rental rental, double pricePerDay);
    }
}
