﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class MiniCalculator : IFeeCalculator
    {
        public double CalculateAmount(Rental rental, double pricePerDay)
        {
            double thisAmount = 0;
            thisAmount += pricePerDay * 3 * 0.75;
            if (rental.DaysRented > 3)
            {
                thisAmount += (rental.DaysRented - 3) * pricePerDay * 0.5;
            }
            return thisAmount;    
        }
    }
}
