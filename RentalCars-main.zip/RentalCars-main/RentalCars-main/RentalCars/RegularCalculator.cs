﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RentalCars
{
    public class RegularCalculator : IFeeCalculator
    {
        public double CalculateAmount(Rental rental, double pricePerDay)
        {
            double thisAmount = 0;
            thisAmount += pricePerDay * 2;
            if (rental.DaysRented > 2)
            {
                thisAmount += (rental.DaysRented - 2) * pricePerDay * 0.75;
            }
            return thisAmount;
        }
    }
}
