﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkLoad.Configurations
{
    public class WorkloadEntityConfiguration : IEntityTypeConfiguration<Entities.WorkLoad>
    {

        public void Configure(EntityTypeBuilder<Entities.WorkLoad> builder)
        {
            
        }
    }
}
