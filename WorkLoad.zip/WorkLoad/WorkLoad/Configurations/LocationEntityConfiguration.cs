﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Entities;

namespace WorkLoad.Configurations
{
    public class LocationEntityConfiguration : IEntityTypeConfiguration<Location>
    {
        public void Configure(EntityTypeBuilder<Location> builder)
        {
            builder.Property(a => a.Address).IsRequired();
            builder.Property(c => c.CityName).IsRequired();
            builder.Property(s => s.StateName).IsRequired();
            builder.Property(c => c.CountyName).IsRequired();
            builder.Property(z => z.Zipcode).IsRequired();
        }
    }
}
