﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkLoad.Entities
{
    public class Location
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string CountyName { get; set; }
        public int Zipcode { get; set; }
        public Location() { }
        public Location(string address, string cityName, string stateName, string countyName, int zipcode)
        {
            Address = address;
            CityName = cityName;
            StateName = stateName;
            CountyName = countyName;
            Zipcode = zipcode;
        }
    }
}
