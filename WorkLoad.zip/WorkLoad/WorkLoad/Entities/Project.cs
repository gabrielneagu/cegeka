﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkLoad.Entities
{
    public class Project
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int NoDays { get; set; }
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
        public Project() { }
        public Project(string name, int noDays, int customerId)
        {
            Name = name;
            NoDays = noDays;
            CustomerId = customerId;
        }
    }
}
