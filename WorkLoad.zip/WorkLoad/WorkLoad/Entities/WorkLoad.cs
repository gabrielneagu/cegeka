﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkLoad.Entities
{
    public class WorkLoad
    {
       
        public int Id { get; set; }
        
        public int NoOfHours { get; set; }

        public int FreelancerId { get; set; }
        public int? ProjectId { get; set; }
        public DateTime Workday { get; set; }
        public decimal PricePerHour { get; set; }
        public Freelancer Freelancer { get; set; }
        public Project Project { get; set; }
        public WorkLoad() { }
        public WorkLoad(int noOfHours, int freelancerId, int projectId, DateTime workday, decimal pricePerHour)
        {
            NoOfHours = noOfHours;
            FreelancerId = freelancerId;
            ProjectId = projectId;
            Workday = workday;
            PricePerHour = pricePerHour;
        }
    }
}
