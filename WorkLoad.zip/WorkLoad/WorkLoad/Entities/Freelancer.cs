﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Entities;

namespace WorkLoad
{
  
        public class Freelancer
        {
            public int Id { get; set; }
            public string FirstName { get; set; }         
            public string LastName { get; set; }
            
            public int LocationId { get; set; }
            
            public Location Location { get; set; }

            public Freelancer() { }
            public Freelancer(string firstName, string lastName, int locationId)
            {
                FirstName = firstName;
                LastName = lastName;
                LocationId = locationId;
            }


        }
    
}
