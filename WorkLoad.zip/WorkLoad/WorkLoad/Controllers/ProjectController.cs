﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Entities;
using WorkLoad.Repositories;

namespace WorkLoad.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectRepository _projectRepository;
        public ProjectController(IProjectRepository projectRepository)
        {
            _projectRepository = projectRepository;
        }
        [HttpGet("displayProjects")]
        public IActionResult DisplayProjects()
        {
            var projects = _projectRepository.GetProjects();
            return Ok(projects);
        }
        [HttpPost("addProject")]
        public IActionResult AddProject(Project project)
        {
            _projectRepository.AddProject(project);
            return Ok();
        }
    }
}
