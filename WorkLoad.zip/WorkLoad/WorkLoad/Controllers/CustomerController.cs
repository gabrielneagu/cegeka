﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Entities;
using WorkLoad.Repositories;

namespace WorkLoad.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private ICustomerRepository _customerRepository;
        public CustomerController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }
        [HttpGet("displayCustomers")]
        public IActionResult DisplayCustomers()
        {
            var customers = _customerRepository.GetCustomers();
            return Ok(customers);
        }
        [HttpPost("addCustomer")]
        public IActionResult AddCustomer(Customer customer)
        {
            _customerRepository.AddCustomer(customer);
            return Ok();
        }
        [HttpGet("displaySum")]
        public IActionResult DisplaySum(string customer, int month, int year)
        {
            var sum = _customerRepository.GetSum(customer, month, year);
            return Ok(sum);
        }
    }
}
