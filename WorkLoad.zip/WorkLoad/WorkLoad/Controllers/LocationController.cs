﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Entities;
using WorkLoad.Repositories;

namespace WorkLoad.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private ILocationRepository _locationRepository { get; set; }
        public LocationController(ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
        }
        [HttpGet("displayLocations")]
        public IActionResult DisplayLocations()
        {
            var locations = _locationRepository.GetLocations();
            return Ok(locations);
        }

        [HttpPost("addLocation")]
        public IActionResult AddLocation(Location location)
        {
            _locationRepository.AddLocation(location);
            return Ok();
        }
    }
}
