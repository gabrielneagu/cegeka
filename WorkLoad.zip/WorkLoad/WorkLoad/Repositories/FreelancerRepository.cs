﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Data;

namespace WorkLoad.Repositories
{
    public class FreelancerRepository : IFreelancerRepository
    {
        private readonly WorkLoadDbContext _context;
        public FreelancerRepository(WorkLoadDbContext context)
        {
            _context = context;
        }
        public List<Freelancer> GetFreelancers()
        {
            return _context.Freelancer.ToList();
        }
        public void AddFreelancer (Freelancer freelancer)
        {
            _context.Freelancer.Add(freelancer);
            _context.SaveChanges();
        }
        public void AddWorkLoad (int freelancerId, int noOfHours, int projectId, DateTime workday, decimal pricePerHour)
        {
            var workLoad = new Entities.WorkLoad()
            {
                NoOfHours = 8,
                FreelancerId = freelancerId,
                ProjectId=projectId,
                Workday=workday,
                PricePerHour=pricePerHour
            };
           _context.WorkLoad.Add(workLoad);
            _context.SaveChanges();
        }

        public string GetHours(int projectId)
        {
            var hours = _context.WorkLoad.Where(w => w.ProjectId == projectId);
            var sumHours = hours.Sum(d=>d.NoOfHours);
            var days = _context.Project.Where(p => p.Id == projectId).Select(p=>p.NoDays*8);
            if (sumHours >= days.First())
            {
                return "Enough workload";
            }
            return "Not enough workload";
        }
    }
}
