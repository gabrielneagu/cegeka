﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WorkLoad.Data;
using WorkLoad.Entities;

namespace WorkLoad.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly WorkLoadDbContext _context;
        public CustomerRepository(WorkLoadDbContext context)
        {
            _context = context;
        }
        public void AddCustomer(Customer customer)
        {
            _context.Customer.Add(customer);
            _context.SaveChanges();
        }

        public List<Customer> GetCustomers()
        {
           return _context.Customer.ToList();
        }

        public decimal GetSum(string customer, int month, int year)
        {
            var prices = from w in _context.WorkLoad
            join f in _context.Freelancer
            on w.FreelancerId equals f.Id
            where _context.Project.Select(p => p.Name).ToString() == customer
            && _context.WorkLoad.Select(w => w.Workday.Month).First() == month
            && _context.WorkLoad.Select(w => w.Workday.Year).First() == year
            select w.NoOfHours * w.PricePerHour;

            var sumPrices = prices.Sum();
            return sumPrices;
        }
    }
}
