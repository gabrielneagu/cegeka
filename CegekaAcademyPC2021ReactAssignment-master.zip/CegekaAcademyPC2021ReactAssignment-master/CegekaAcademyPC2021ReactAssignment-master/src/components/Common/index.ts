export { default as WithLightbox } from './WithLightBox';
export { default as DeleteButton } from './DeleteButton';
