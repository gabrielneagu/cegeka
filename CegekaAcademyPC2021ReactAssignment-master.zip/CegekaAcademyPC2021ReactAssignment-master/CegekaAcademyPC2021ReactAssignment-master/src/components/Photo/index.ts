import Photo from './Photo';
export { default as PhotoForm } from './PhotoForm';
export { default as PhotoList } from './PhotoList';
export default Photo;