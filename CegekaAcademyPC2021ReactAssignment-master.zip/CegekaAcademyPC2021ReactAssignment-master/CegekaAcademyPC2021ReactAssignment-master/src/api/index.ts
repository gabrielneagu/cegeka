import sampleAlbums from './sampleAlbums.json';
import samplePhotos from './samplePhotos.json';

export function getAlbums() {
  return sampleAlbums;
}

export function getPhotos() {
  return samplePhotos;
}