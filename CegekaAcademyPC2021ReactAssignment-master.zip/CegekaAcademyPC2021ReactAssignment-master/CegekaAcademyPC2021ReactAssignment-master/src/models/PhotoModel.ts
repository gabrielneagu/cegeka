export interface PhotoModel {
    id: string;
    title: string;
    description: string;
    url: string;
}