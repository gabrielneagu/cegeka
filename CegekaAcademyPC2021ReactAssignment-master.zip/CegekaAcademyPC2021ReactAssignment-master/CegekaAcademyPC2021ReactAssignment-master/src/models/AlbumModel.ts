export interface AlbumModel {
    id: string;
    name: string;
    description: string;
    tags: string[];
    photosIds: string[];
}