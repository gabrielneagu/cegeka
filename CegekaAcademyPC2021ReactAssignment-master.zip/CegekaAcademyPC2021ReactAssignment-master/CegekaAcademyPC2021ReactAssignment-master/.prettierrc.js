module.exports = {
  bracketSpacing: true,
  preserveWhitespaces: true,
  singleQuote: true,
  trailingComma: 'all',
  jsxBracketSameLine: false,
  arrowParens: 'always',
  parser: 'typescript',
  printWidth: 120,
  endOfLine:'auto'
}
